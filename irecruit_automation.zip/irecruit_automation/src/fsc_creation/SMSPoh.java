package fsc_creation;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SMSPoh {
	public static String getOTP() throws InterruptedException {
		//Setting webdriver
		System.setProperty("webdriver.chrome.driver", "C:/Users/HPGL092/Documents/chromedriver/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		
		WebDriver driver = new ChromeDriver(options);
		
		//defining an explicit wait
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofMinutes(1));
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		
		int smsFinder = 1;
		
		//staring smspoh portal
		driver.get("https://smspoh.com/portal/");
		
		driver.manage().window().maximize();
		
		WebElement username = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("loginform-username")));
		username.sendKeys("");
		
		WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("loginform-password")));
		password.sendKeys("");
		
		WebElement loginButton = driver.findElement(By.cssSelector(".btn-primary"));
		loginButton.click();
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".menu_section>ul>li>a>span"))).click();
		
		WebElement smsMessages = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("body > div.container.body > div.right_col > div.campaign-view.b-white.pad-large.bordered.radius > div.row > div:nth-child(2) > div > div > div > a > div.col-md-8.col-sm-12.animDelayShort.col-xs-12.text-right.animator.animated > h2")));
		smsMessages.click();
		
		WebElement mobileNo = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".table.table-striped.table-bordered > tbody > tr:nth-child(1) > td:nth-child(1)")));
		String smsContent = "";
		//System.out.println(mobileNo.getText());
		while(mobileNo.getText() != null)
		{
			if(mobileNo.getText().equals(""))
			{
				smsContent = driver.findElement(By.cssSelector(".table.table-striped.table-bordered > tbody > tr:nth-child(" + smsFinder + ") > td:nth-child(6)")).getText();
				if(smsContent.contains("OTP"))
				{
					break;
				}
			}
			++smsFinder;
			mobileNo = driver.findElement(By.cssSelector(".table.table-striped.table-bordered > tbody > tr:nth-child(" + smsFinder + ") > td:nth-child(1)"));
			jse.executeScript("arguments[0].scrollIntoView(false)", mobileNo);
		}
		
		
		String otp = smsContent.substring(20, 26);
		
		//System.out.println(otp);
		
		driver.quit();
		
		return otp;
	}
}
