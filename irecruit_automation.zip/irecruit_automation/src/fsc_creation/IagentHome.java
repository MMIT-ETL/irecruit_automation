package fsc_creation;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class IagentHome {

	/**
	 * @param args
	 * @throws InterruptedException
	 */
	public static void main(String[] args) throws InterruptedException {
		
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:/Users/HPGL092/Documents/chromedriver/chromedriver.exe");
		
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		options.addArguments("incognito");
		
		//Start of Variable Declarations
		//Declaring new ChromeDriver
		WebDriver driver = new ChromeDriver(options);
		JFrame frame = new JFrame();
		
		driver.manage().window().maximize();
		
		//Opening iAgent URL 
		driver.get("https://uat.aia.com.mm/iagent");
		
		//Explicit wait
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofMinutes(10));
		//JSE for page scrolling
		JavascriptExecutor jse =(JavascriptExecutor)driver;
		
		//Login.logIn(driver);
		
		Agent[] agents = DataFields.getData();
		
		
		JOptionPane.showMessageDialog(frame,
			    "Please input username, password and OTP and login first. After that, the task will continue automatically.");
		
		WebElement iRecruitPage = null;
		
		//Click menu and go to iRecruit
		do {
			WebElement menuButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".menuBtn")));
			menuButton.click();
			WebElement iRecruit = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='IRECRUIT']")));
			iRecruit.click();
			Thread.sleep(500);
			iRecruit.click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div.drawer-mask"))).click();
			Thread.sleep(1000);
			try{
				iRecruitPage = driver.findElement(By.xpath("//h4[text()='ALL FSC']"));
			}catch (NoSuchElementException e) {
				iRecruitPage = null;
			}
		} while(iRecruitPage == null);
		
		
		for(int i = 0; i < agents.length; i++) {
			Irecruit.createFSC(agents[i],driver);
			if(i>=agents.length-1)
			{
				break;
			}
			Thread.sleep(15000);
			WebElement closeButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div.rootRoute>div.dialog-container>div.el-dialog__wrapper>div>div.el-dialog__header>button>i.el-dialog__close")));
			closeButton.click();
		}
		
		JOptionPane.showMessageDialog(frame,
			    "Agent Creation Completed!");
		
	}
	
}
