package fsc_creation;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Irecruit {
	public static void createFSC(Agent agents, WebDriver driver) throws InterruptedException {
		

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofMinutes(5));
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		
		//Click new fsc
		WebElement newFsc = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("button.white")));
		jse.executeScript("arguments[0].scrollIntoView(false)", newFsc);
		newFsc.click();
		
		String cityCode = "";
		String townshipCode = "";
		String type = "";
		String number = "";
		
		if(agents.idType.equals("NRC")) {
			cityCode = agents.idNo.substring(0,agents.idNo.indexOf("/"));
			townshipCode = agents.idNo.substring(agents.idNo.indexOf("/")+1, agents.idNo.indexOf("("));
			type = agents.idNo.substring(agents.idNo.indexOf("("),agents.idNo.indexOf(")")+1);
			number = agents.idNo.substring(agents.idNo.indexOf(")")+1,agents.idNo.length());
		}
		
		
		Thread.sleep(1000);
		
		//input fullname
		WebElement salutation = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("form.el-form>div.el-form-item:nth-child(1)>div>div.el-select>div>span>span>i")));
		salutation.click();
		Thread.sleep(500);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='" + agents.salution +"']"))).click();
		
		WebElement name = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("form.el-form>div.el-form-item:nth-child(1)>div>div:nth-child(2)>input")));
		name.sendKeys(agents.fullName);
		
		//select gender
		WebElement gender = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='" + agents.gender + "']")));
		gender.click();
		
		WebElement contactCode = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("form.el-form> div.el-form-item:nth-child(3) >div > div.newContactNumber > input:nth-child(1)")));
		contactCode.sendKeys("95");
		
		//input mobilenumber
		WebElement mobile = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("form.el-form> div.el-form-item:nth-child(3) >div > div.newContactNumber > input:nth-child(2)")));
		mobile.sendKeys(agents.mobile);
		
		//input email
		WebElement email = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("form.el-form> div.el-form-item:nth-child(4) >div > div > input:nth-child(1)")));
		email.sendKeys(agents.email);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("form.el-form> div.el-form-item:nth-child(5) >div > div > input:nth-child(1)"))).sendKeys(agents.email);
		
		
		//select nationality
		WebElement nationality = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("form.el-form>div.el-form-item:nth-child(6)>div>div.el-select>div > input")));
		nationality.click();
		nationality = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='" + agents.nationality + "']")));
		jse.executeScript("arguments[0].scrollIntoView({block:\"center\"})", nationality);
		Thread.sleep(500);
		nationality.click();
		
		//input date of birth
		WebElement birthDate = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("form.el-form>div.el-form-item:nth-child(7)>div > div.el-date-editor > input")));
		birthDate.sendKeys(agents.dob);
		
		//select marital status
		WebElement marital = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("form.el-form>div.el-form-item:nth-child(9)>div>div.el-select>div > input")));
		marital.click();
		Thread.sleep(500);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='" + agents.marital + "']"))).click();
		
		//select id type
		WebElement idType = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("form.el-form>div.el-form-item:nth-child(12)>div>div.el-select>div > input")));
		idType.click();
		Thread.sleep(500);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='" + agents.idType + "']"))).click();
		
		Thread.sleep(500);
		//input id number
		if(agents.idType.equals("NRC"))
		{
			WebElement idCity = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("form.el-form>div.el-form-item:nth-child(13)>div>div.el-select>div > input")));
			idCity.click();
			idCity = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='" + cityCode + "']")));
			jse.executeScript("arguments[0].scrollIntoView({block:\"center\"})", idCity);
			Thread.sleep(500);
			idCity.click();
			
			WebElement idTownship = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("form.el-form>div.el-form-item:nth-child(14)>div>div.el-select>div > input")));
			idTownship.click();
			idTownship = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'" + townshipCode + "')]")));
			jse.executeScript("arguments[0].scrollIntoView({block:\"center\"})", idTownship);
			Thread.sleep(500);
			idTownship.click();
			
			WebElement nrcType = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("form.el-form>div.el-form-item:nth-child(15)>div>div.el-select>div > input")));
			nrcType.click();
			nrcType = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'" + type + "')]")));
			jse.executeScript("arguments[0].scrollIntoView({block:\"center\"})", nrcType);
			Thread.sleep(500);
			nrcType.click();
			
			WebElement nrcNumber = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("form.el-form>div.el-form-item:nth-child(16)>div>div>input")));
			nrcNumber.sendKeys(number);
		}
		
		System.out.println(agents.city);
		//select city
		WebElement city = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("form.el-form>div.el-form-item:nth-child(18)>div>div.el-select>div > input")));
		city.click();
		city = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'" + agents.city + "')]")));
		jse.executeScript("arguments[0].scrollIntoView({block:\"center\"})", city);
		Thread.sleep(500);
		city.click();
		
		//select district
		WebElement district = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("form.el-form>div.el-form-item:nth-child(19)>div>div.el-select>div > input")));
		district.click();
		district = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'" + agents.district + "')]")));
		jse.executeScript("arguments[0].scrollIntoView({block:\"center\"})", district);
		Thread.sleep(500);
		district.click();
		
		//select township
		WebElement township = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("form.el-form>div.el-form-item:nth-child(20)>div>div.el-select>div > input")));
		township.click();
		township = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'" + agents.township + "')]")));
		jse.executeScript("arguments[0].scrollIntoView({block:\"center\"})", township);
		Thread.sleep(500);
		township.click();
		
		//input street
		WebElement street = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("form.el-form>div.el-form-item:nth-child(21)>div>div>input")));
		street.sendKeys(agents.street);
		
		//input building
		WebElement building = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("form.el-form>div.el-form-item:nth-child(22)>div>div>input")));
		building.sendKeys(agents.building);
		
		//input referral code
		WebElement referral = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("form.el-form>div.el-form-item:nth-child(23)>div>div>input")));
		jse.executeScript("arguments[0].scrollIntoView({block:\"center\"})", referral);
		referral.sendKeys(agents.referral);
		
		//click create
		WebElement createButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button/span[text()='CREATE']")));
		createButton.click();
		
	}
}
