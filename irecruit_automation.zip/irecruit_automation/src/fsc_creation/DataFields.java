package fsc_creation;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

import javax.swing.JFileChooser;

class Agent {
	String salution;
	String fullName;
	String gender;
	String mobile;
	String email;
	String nationality;
	String dob;
	String marital;
	String idType;
	String idNo;
	String city;
	String district;
	String township;
	String street;
	String building;
	String referral;
	
	Agent(String[] data) {
		this.salution = data[0];
		this.fullName = data[1];
		this.gender = data[2];
		this.mobile = data[3];
		this.email = data[4];
		this.nationality = data[5];
		this.dob = data[6];
		this.marital = data[7];
		this.idType = data[8];
		this.idNo = data[9];
		this.city = data[10];
		this.district = data[11];
		this.township = data[12];
		this.street = data[13];
		this.building = data[14];
		this.referral = data[15];
	}
}

public class DataFields {
	public static Agent[] getData() {
		String line = "";
		String regex = ",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)";
		String lineToRemove = "Salutation,Full Name,Gender,Contact Number,Email Address,Nationality,Date of Birth,Marital Status,ID Type,ID Number,Province/City,District,Township,Street Name,Building/Unit No,Referral Code";
		//System.out.println(br.lines().count());
		Agent[] agents = new Agent[400];
		int count = 0;
		//String[] data = new String[2];
		
		JFileChooser fc = new JFileChooser("C:\\");
		fc.showOpenDialog(null);
		File chosenFile = fc.getSelectedFile();
		
		try {
			BufferedReader br = new BufferedReader(new FileReader(chosenFile.getPath().replace("\\", "\\\\")));
			while((line = br.readLine()) != null)
			{
				String trimmedLine = line.trim();
				if(trimmedLine.equals(lineToRemove)) continue;
				String[] data = line.split(regex, -1);
				agents[count] = new Agent(data);
				++count;
			}
		} catch (IOException e)
		{
			e.printStackTrace();
		}
		//System.out.println(br.lines().count());
		//scenarios = new Scenario[(int)br.lines().count()];
		
		
		
		//return scenarios;
		
		agents = Arrays.stream(agents)
				.filter(s -> (s != null))
				.toArray(Agent[]::new);
			
		
		return agents;
	}
	
}
