package fsc_creation;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Login {

	public static void logIn(WebDriver driver) throws InterruptedException {
		// TODO Auto-generated method stub
		
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		
		//input username
		WebElement username = driver.findElement(By.cssSelector(".accountNum:nth-child(3) > input"));
		username.sendKeys("");
		
		//input password
		WebElement password = driver.findElement(By.cssSelector(".accountNum:nth-child(4) > input"));
		password.sendKeys("");
		
		//choose mobile for otp
		WebElement mobileRadio = driver.findElement(By.cssSelector(".radioSelect > .el-radio:nth-child(2) > span.el-radio__label"));
		jse.executeScript("arguments[0].scrollIntoView(true)", mobileRadio);
		mobileRadio.click();
		
		//click send otp
		WebElement sendEmailButton = driver.findElement(By.cssSelector(".sendEmil"));
		sendEmailButton.click();
		
		//get otp from SMSPoh
		String otp = SMSPoh.getOTP();
		
		//input OTP and login
		WebElement otpBox = driver.findElement(By.cssSelector(".accountNum:nth-child(6) > input[type='text']"));
		otpBox.sendKeys(otp);
		
		WebElement loginButton = driver.findElement(By.cssSelector(".mdLoad > button"));
		loginButton.click();
		
	}

}
